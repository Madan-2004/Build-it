from django.contrib import admin
from .models import Event, Agenda, Speaker
admin.site.register(Event)
admin.site.register(Agenda)
admin.site.register(Speaker)
# Register your models here.
